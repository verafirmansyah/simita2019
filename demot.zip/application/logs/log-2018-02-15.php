<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-15 05:02:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-02-15 05:02:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2018-02-15 05:02:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-02-15 05:02:09 --> 404 Page Not Found: Assets/js
ERROR - 2018-02-15 05:02:10 --> 404 Page Not Found: Assets/fonts
ERROR - 2018-02-15 05:02:10 --> 404 Page Not Found: Assets/js
INFO - 2018-02-15 05:03:19 --> Config Class Initialized
INFO - 2018-02-15 05:03:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 05:03:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 05:03:19 --> Utf8 Class Initialized
INFO - 2018-02-15 05:03:19 --> URI Class Initialized
INFO - 2018-02-15 05:03:19 --> Router Class Initialized
INFO - 2018-02-15 05:03:19 --> Output Class Initialized
INFO - 2018-02-15 05:03:19 --> Security Class Initialized
DEBUG - 2018-02-15 05:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 05:03:19 --> Input Class Initialized
INFO - 2018-02-15 05:03:19 --> Language Class Initialized
INFO - 2018-02-15 05:03:19 --> Loader Class Initialized
INFO - 2018-02-15 05:03:19 --> Helper loaded: url_helper
INFO - 2018-02-15 05:03:19 --> Helper loaded: file_helper
INFO - 2018-02-15 05:03:19 --> Helper loaded: html_helper
INFO - 2018-02-15 05:03:19 --> Helper loaded: ict_helper
INFO - 2018-02-15 05:03:19 --> Database Driver Class Initialized
INFO - 2018-02-15 05:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 05:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 05:03:19 --> Pagination Class Initialized
INFO - 2018-02-15 05:03:19 --> Helper loaded: form_helper
INFO - 2018-02-15 05:03:19 --> Form Validation Class Initialized
INFO - 2018-02-15 05:03:19 --> Controller Class Initialized
INFO - 2018-02-15 05:03:19 --> Model Class Initialized
INFO - 2018-02-15 05:03:19 --> Model Class Initialized
INFO - 2018-02-15 05:03:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 05:03:19 --> File loaded: C:\xampp\htdocs\simit\application\views\supplier/edit.php
INFO - 2018-02-15 05:03:19 --> File loaded: C:\xampp\htdocs\simit\application\views\template/header.php
INFO - 2018-02-15 05:03:19 --> File loaded: C:\xampp\htdocs\simit\application\views\template/sidebar.php
INFO - 2018-02-15 05:03:19 --> File loaded: C:\xampp\htdocs\simit\application\views\template/template.php
INFO - 2018-02-15 05:03:19 --> Final output sent to browser
DEBUG - 2018-02-15 05:03:19 --> Total execution time: 0.4020
INFO - 2018-02-15 05:03:19 --> Config Class Initialized
INFO - 2018-02-15 05:03:19 --> Hooks Class Initialized
DEBUG - 2018-02-15 05:03:19 --> UTF-8 Support Enabled
INFO - 2018-02-15 05:03:19 --> Utf8 Class Initialized
INFO - 2018-02-15 05:03:19 --> URI Class Initialized
INFO - 2018-02-15 05:03:19 --> Router Class Initialized
INFO - 2018-02-15 05:03:19 --> Output Class Initialized
INFO - 2018-02-15 05:03:19 --> Security Class Initialized
DEBUG - 2018-02-15 05:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 05:03:20 --> Input Class Initialized
INFO - 2018-02-15 05:03:20 --> Language Class Initialized
ERROR - 2018-02-15 05:03:20 --> 404 Page Not Found: Assets/js
INFO - 2018-02-15 05:03:20 --> Config Class Initialized
INFO - 2018-02-15 05:03:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 05:03:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 05:03:20 --> Utf8 Class Initialized
INFO - 2018-02-15 05:03:20 --> URI Class Initialized
INFO - 2018-02-15 05:03:20 --> Router Class Initialized
INFO - 2018-02-15 05:03:20 --> Output Class Initialized
INFO - 2018-02-15 05:03:20 --> Security Class Initialized
DEBUG - 2018-02-15 05:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 05:03:20 --> Input Class Initialized
INFO - 2018-02-15 05:03:20 --> Language Class Initialized
ERROR - 2018-02-15 05:03:20 --> 404 Page Not Found: Assets/fonts
INFO - 2018-02-15 05:03:20 --> Config Class Initialized
INFO - 2018-02-15 05:03:20 --> Hooks Class Initialized
DEBUG - 2018-02-15 05:03:20 --> UTF-8 Support Enabled
INFO - 2018-02-15 05:03:20 --> Utf8 Class Initialized
INFO - 2018-02-15 05:03:20 --> URI Class Initialized
INFO - 2018-02-15 05:03:20 --> Router Class Initialized
INFO - 2018-02-15 05:03:20 --> Output Class Initialized
INFO - 2018-02-15 05:03:20 --> Security Class Initialized
DEBUG - 2018-02-15 05:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 05:03:20 --> Input Class Initialized
INFO - 2018-02-15 05:03:20 --> Language Class Initialized
ERROR - 2018-02-15 05:03:20 --> 404 Page Not Found: Assets/js
INFO - 2018-02-15 05:03:21 --> Config Class Initialized
INFO - 2018-02-15 05:03:21 --> Hooks Class Initialized
DEBUG - 2018-02-15 05:03:21 --> UTF-8 Support Enabled
INFO - 2018-02-15 05:03:21 --> Utf8 Class Initialized
INFO - 2018-02-15 05:03:21 --> URI Class Initialized
INFO - 2018-02-15 05:03:21 --> Router Class Initialized
INFO - 2018-02-15 05:03:21 --> Output Class Initialized
INFO - 2018-02-15 05:03:21 --> Security Class Initialized
DEBUG - 2018-02-15 05:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 05:03:21 --> Input Class Initialized
INFO - 2018-02-15 05:03:21 --> Language Class Initialized
INFO - 2018-02-15 05:03:21 --> Loader Class Initialized
INFO - 2018-02-15 05:03:21 --> Helper loaded: url_helper
INFO - 2018-02-15 05:03:21 --> Helper loaded: file_helper
INFO - 2018-02-15 05:03:21 --> Helper loaded: html_helper
INFO - 2018-02-15 05:03:21 --> Helper loaded: ict_helper
INFO - 2018-02-15 05:03:21 --> Database Driver Class Initialized
INFO - 2018-02-15 05:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-15 05:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-02-15 05:03:21 --> Pagination Class Initialized
INFO - 2018-02-15 05:03:21 --> Helper loaded: form_helper
INFO - 2018-02-15 05:03:21 --> Form Validation Class Initialized
INFO - 2018-02-15 05:03:21 --> Controller Class Initialized
INFO - 2018-02-15 05:03:21 --> Model Class Initialized
INFO - 2018-02-15 05:03:21 --> Model Class Initialized
INFO - 2018-02-15 05:03:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-15 05:03:21 --> File loaded: C:\xampp\htdocs\simit\application\views\supplier/edit.php
INFO - 2018-02-15 05:03:21 --> File loaded: C:\xampp\htdocs\simit\application\views\template/header.php
INFO - 2018-02-15 05:03:21 --> File loaded: C:\xampp\htdocs\simit\application\views\template/sidebar.php
INFO - 2018-02-15 05:03:21 --> File loaded: C:\xampp\htdocs\simit\application\views\template/template.php
INFO - 2018-02-15 05:03:21 --> Final output sent to browser
DEBUG - 2018-02-15 05:03:21 --> Total execution time: 0.3560
INFO - 2018-02-15 05:03:22 --> Config Class Initialized
INFO - 2018-02-15 05:03:22 --> Hooks Class Initialized
DEBUG - 2018-02-15 05:03:22 --> UTF-8 Support Enabled
INFO - 2018-02-15 05:03:22 --> Utf8 Class Initialized
INFO - 2018-02-15 05:03:22 --> URI Class Initialized
INFO - 2018-02-15 05:03:22 --> Router Class Initialized
INFO - 2018-02-15 05:03:22 --> Output Class Initialized
INFO - 2018-02-15 05:03:22 --> Security Class Initialized
DEBUG - 2018-02-15 05:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 05:03:22 --> Input Class Initialized
INFO - 2018-02-15 05:03:22 --> Language Class Initialized
ERROR - 2018-02-15 05:03:22 --> 404 Page Not Found: Assets/js
INFO - 2018-02-15 05:03:22 --> Config Class Initialized
INFO - 2018-02-15 05:03:22 --> Hooks Class Initialized
DEBUG - 2018-02-15 05:03:22 --> UTF-8 Support Enabled
INFO - 2018-02-15 05:03:22 --> Utf8 Class Initialized
INFO - 2018-02-15 05:03:22 --> URI Class Initialized
INFO - 2018-02-15 05:03:22 --> Router Class Initialized
INFO - 2018-02-15 05:03:22 --> Output Class Initialized
INFO - 2018-02-15 05:03:22 --> Security Class Initialized
DEBUG - 2018-02-15 05:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-15 05:03:22 --> Input Class Initialized
INFO - 2018-02-15 05:03:22 --> Language Class Initialized
ERROR - 2018-02-15 05:03:22 --> 404 Page Not Found: Assets/fonts
