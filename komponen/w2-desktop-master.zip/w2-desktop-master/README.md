# W2-desktop
Open Source library for building Web Application with the Desktop UI

![W2-desktop | didanurwanda](http://www.didanurwanda.com/uploads/produk/123b5f74f1a7c1f03ba09c300a5b0956.jpg)

Demo and Documentation [http://w2desktop.didanurwanda.com](http://w2desktop.didanurwanda.com)

## Creator

Twitter : [https://twitter.com/didanurwanda](https://twitter.com/didanurwanda)

Github : [https://github.com/didanurwanda](https://github.com/didanurwanda)

Facebook : [https://www.facebook.com/didanurwanda](https://www.facebook.com/didanurwanda)

Website : [http://www.didanurwanda.com](http://www.didanurwanda.com)

Blog : [http://blog.didanurwanda.com](http://blog.didanurwanda.com)

Email : didanurwanda@gmail.com

