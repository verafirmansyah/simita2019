<?
print_r($_POST);
?>